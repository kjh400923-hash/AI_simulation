const player = { x: 4, y: 9, facing: 'up' };
const speed = 4;
const pressed = new Set();
const controls = new Set(['arrowup','arrowdown','arrowleft','arrowright','w','a','s','d']);
document.addEventListener('keydown', event => {
  const key = event.key.toLowerCase();
  if (!controls.has(key)) return;
  event.preventDefault();
  pressed.add(key);
});
document.addEventListener('keyup', event => pressed.delete(event.key.toLowerCase()));
window.addEventListener('blur', () => pressed.clear());
document.addEventListener('visibilitychange', () => pressed.clear());
const held = (arrow, letter) => Number(pressed.has(arrow) || pressed.has(letter));
function updateMovement(dt) {
  const dx = held('arrowright','d') - held('arrowleft','a');
  const dy = held('arrowdown','s') - held('arrowup','w');
  const length = Math.hypot(dx, dy);
  if (!length) return;
  if (dx && (!dy || player.facing === 'left' || player.facing === 'right')) player.facing = dx > 0 ? 'right' : 'left';
  else player.facing = dy > 0 ? 'down' : 'up';
  const x = Math.max(0, Math.min(MAP_WIDTH-1,player.x+dx/length*speed*dt));
  const y = Math.max(0, Math.min(MAP_HEIGHT-1,player.y+dy/length*speed*dt));
  if (!blockedAt(x,player.y)) player.x=x;
  if (!blockedAt(player.x,y)) player.y=y;
}
let previous;
function frame(now) {
  const dt = previous === undefined ? 0 : Math.min(0.05, (now - previous) / 1000);
  if (introStage === "arrival") tickArrival(dt);
  else if (dialogue.hidden && introStage !== "seated") updateMovement(dt);
  updateSteps(dt,player);
  previous = now;
  drawMap();
  drawNpcs();
  drawPlayer(player);
  if (introStage === "done") updateHint(); else introHint();
  requestAnimationFrame(frame);
}
drawMap();
drawPlayer(player);
requestAnimationFrame(frame);
