let introStage='arrival', lineIndex=0;
const notebook=document.querySelector('#notebook');
const quests=document.querySelector('#quests');
const questText=['법적으로 문제가 없는 절차인지 확인한다.','유가족의 동의가 있었는지 확인한다.','스타워즈 감독에게 실제 출연 여부를 확인한다.'];
let completedQuests=0;
function renderQuests(){const list=quests.querySelector('ol');list.replaceChildren();questText.forEach((text,i)=>{const li=document.createElement('li');li.textContent=i>completedQuests?'???':(i<completedQuests?'✓ ':'')+text;list.append(li);});}
function completeQuest(index){if(index!==completedQuests+1 || index>questText.length)return false;completedQuests++;renderQuests();return true;}
const introLines=[
 ['편집장','오늘 제보 하나가 들어왔네.'],
 ['편집장','스타워즈 영화 아나? 레아 공주 역을 맡았던 배우 캐리 피셔에 관한 일이야.'],
 ['나','뭐라고 대답할까?',['캐리 피셔는 이미 세상을 떠났잖아요?','캐리 피셔의 사망 기사가 2016년쯤 나오지 않았나요?']],
 ['편집장','맞아. 캐리 피셔는 2016년에 세상을 떠났지. 그런데 다음 스타워즈 영화에 다시 등장한다는 제보가 왔어.'],
 ['나','그게 가능한 거예요?'],
 ['편집장','나도 모르네. 그러니 자네에게 일을 맡기려고 해.'],
 ['편집장','내일까지 기사를 써야 한다네. 그러니 그전까지 이 제보가 진실인지 거짓인지 확인해 주게나.'],
 ['편집장','이 수첩을 가져가게. 조사할 내용을 적어 뒀으니, 그걸 바탕으로 단서를 모으면 될 걸세.'],
 ['나','네, 알겠습니다.']
];
goal.textContent='방송부실에 들어가는 중…';
function tickArrival(dt){player.y=Math.max(6.4,player.y-dt*2.6);if(player.y<=6.4){introStage='greeting';say('편집장','앉아보게.'); dialogue.querySelector('small').textContent='Enter / E 다음';effect('talk');}}
function nearChair(){return Math.hypot(player.x-4,player.y-4.55)<.85;}
function introHint(){const text=introStage==='chair'?(nearChair()?'E: 의자에 앉기':'편집장 책상 앞 의자에 가까이 가세요.') : '';if(hint.textContent!==text)hint.textContent=text;}
function readIntro(){const row=introLines[lineIndex];if(!row)return finishIntro();const [name,text,opts]=row;say(name,text,opts?.map(answer=>[answer,()=>{effect('talk');say('나',answer);dialogue.querySelector('small').textContent='Enter / E 다음';}]));dialogue.querySelector('small').textContent=opts?'선택지를 고르세요':'Enter / E 다음';effect('talk');}
function finishIntro(){introStage='done';dialogue.hidden=true;pressed.clear();setPhase(1);goal.textContent='장면 1 완료 · 다음 조사는 이후 장면에서 이어집니다.';notebook.hidden=false;quests.hidden=false;renderQuests();const li=document.createElement('li');li.textContent='제보: 세상을 떠난 캐리 피셔가 스타워즈 신작에 다시 등장한다고 한다. 출처와 근거를 확인하자.';notebook.querySelector('ul').append(li);document.querySelector('#pickup').hidden=false;effect('get');}
document.addEventListener('keydown',e=>{
 if(introStage==='done'||!['KeyE','Enter','NumpadEnter','Escape'].includes(e.code))return;
 if(introStage==='chair'&&e.code!=='KeyE')return;
 if(introStage==='seated'&&document.querySelector('#choices button')&&e.key==='Enter'&&e.target instanceof HTMLButtonElement&&e.target.closest('#choices'))return;
 e.preventDefault();e.stopImmediatePropagation();if(e.repeat||e.code==='Escape')return;
 if(introStage==='greeting'){introStage='chair';dialogue.hidden=true;goal.textContent='책상 앞 의자 가까이에서 E를 누르세요.';}
 else if(introStage==='chair'&&nearChair()){introStage='seated';player.x=4;player.y=4.55;player.facing='up';effect('sit');goal.textContent='편집장의 이야기를 들어 보세요.';readIntro();}
 else if(introStage==='seated'&&!document.querySelector('#choices button')){lineIndex++;readIntro();}
},true);
