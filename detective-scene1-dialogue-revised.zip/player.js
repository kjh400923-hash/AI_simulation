const sprites = Object.fromEntries(Object.entries({down:'detective',up:'up',left:'left',right:'right'}).map(([direction, name]) => {
  const image = new Image();
  image.src = `assets/${name}.png`;
  return [direction, image];
}));
function drawPlayer(player) {
  const detective = sprites[player.facing];
  if (!detective.naturalWidth || !detective.naturalHeight) return;
  const scale = Math.min(TILE * 1.35 / detective.naturalWidth, TILE * 1.41 / detective.naturalHeight);
  const w = detective.naturalWidth * scale, h = detective.naturalHeight * scale;
  ctx.drawImage(detective, Math.max(0, Math.min(canvas.width - w, (player.x + 0.5) * TILE - w / 2)), Math.max(0, (player.y + 0.97) * TILE - h), w, h);
}
