const boothFurniture=[
 {box:[96,96,78,24],type:'desk'},
 {box:[15,38,53,36],type:'shelf'}, {box:[231,38,52,36],type:'shelf'},
 {box:[13,116,41,34],type:'printer'}, {box:[242,115,45,42],type:'files'},
 {box:[15,217,50,27],type:'sofa'}, {box:[241,224,25,24],type:'plant'}
];
function drawBooth(c){
 const r=(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h);};
 r(0,0,300,300,'#e9dcc7');
 for(let y=28;y<300;y+=18){r(0,y,300,1,'#d8c8af');for(let x=(y%36?30:0);x<300;x+=60)r(x,y,1,18,'#d8c8af');}
 r(0,0,300,28,'#526c78');r(0,26,300,4,'#a88c6a');
 r(87,4,125,20,'#c28e5e');
 for(let i=0;i<6;i++){r(92+i*19,6+i%2*2,14,13,i%2?'#fbe1a8':'#f5f1e7');r(94+i*19,12+i%2*2,9,1,'#887769');}
 r(91,168,119,91,'#7d9c98');r(95,172,111,83,'#92aca5');
 r(124,132,22,20,'#725541');r(126,134,18,14,'#a87959');r(124,149,22,3,'#5e483d');
 for(const {box:[x,y,w,h],type} of boothFurniture){
   r(x+2,y+4,w,h,'#cbb89d');
   r(x,y,w,h,type==='sofa'?'#466773':'#765541');
   r(x,y,w,h-6,type==='sofa'?'#7296a0':'#ad805d');
   if(type==='desk'){
     r(x+11,y-8,29,19,'#293e48');r(x+13,y-6,25,14,'#92bccc');r(x+23,y+11,6,4,'#344952');r(x+18,y+15,16,2,'#344952');
     r(x+48,y+4,19,13,'#f5edd9');r(x+51,y+8,12,1,'#867869');r(x+51,y+11,9,1,'#867869');
   }else if(type==='shelf'||type==='files'){
     r(x+4,y+5,w-8,h-14,'#564d48');
     ['#758f91','#9c675c','#dec48e','#b6b9a1','#7390a4'].forEach((color,i)=>r(x+6+i*6,y+8+i%2*3,5,h-18-i%2*3,color));
   }else if(type==='printer'){
     r(x+5,y+5,w-10,20,'#4a5961');r(x+9,y+7,w-18,5,'#83969c');r(x+13,y+17,w-26,8,'#f4efde');
   }else if(type==='sofa'){r(x+5,y+10,19,11,'#93adb1');r(x+26,y+10,19,11,'#93adb1');}
   else {r(x+5,y+11,15,12,'#b97758');r(x+4,y+1,16,13,'#4d7757');r(x+9,y-4,10,13,'#75996a');}
 }
}
