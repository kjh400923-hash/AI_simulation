const MAP_WIDTH = 10;
const MAP_HEIGHT = 10;
const TILE = 30;
const canvas = document.querySelector('#map');
canvas.width = MAP_WIDTH * TILE;
canvas.height = MAP_HEIGHT * TILE;
const ctx = canvas.getContext('2d');

function drawMap() {
  ctx.fillStyle = rooms[room].color;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  if(room==='booth'){drawBooth(ctx);return;}
  ctx.strokeStyle = '#ddd';
  for (let y = 0; y < MAP_HEIGHT; y++) {
    for (let x = 0; x < MAP_WIDTH; x++) {
      ctx.strokeRect(x * TILE + 0.5, y * TILE + 0.5, TILE, TILE);
    }
  }
}
