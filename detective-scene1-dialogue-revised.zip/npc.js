const editorSprite=new Image();
editorSprite.src="assets/editor.png";
function nearestNpc(player) {
  let nearest = null, range = 1.75;
  for (const npc of rooms[room].objects) {
    const distance = Math.hypot(npc.x-player.x,npc.y-player.y);
    if (distance < range) { nearest = npc; range = distance; }
  }
  return nearest;
}
function drawNpcs() {
  for (const npc of rooms[room].objects) {
    if(npc.id==='editor' && editorSprite.naturalWidth){
      const h=TILE*1.65,w=h*editorSprite.naturalWidth/editorSprite.naturalHeight;
      ctx.drawImage(editorSprite,(npc.x+.5)*TILE-w/2,(npc.y+.94)*TILE-h,w,h);
      label(npc.name,(npc.x+.5)*TILE,(npc.y+1.16)*TILE); continue;
    }
    if(room==='booth' && npc.to){label(npc.name+' ↗',(npc.x+.5)*TILE,(npc.y+.52)*TILE);continue;}
    ctx.fillStyle = npc.to ? '#285777' : '#555';
    ctx.fillRect((npc.x+.2)*TILE,(npc.y+.2)*TILE,.6*TILE,.6*TILE);
    ctx.fillStyle = '#fff'; ctx.font = '11px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(npc.name,(npc.x+.5)*TILE,(npc.y+.5)*TILE);
  }
}

function label(text,x,y){ctx.font="bold 11px sans-serif";ctx.textAlign="center";ctx.textBaseline="middle";const w=ctx.measureText(text).width;ctx.fillStyle="#294452";ctx.fillRect(x-w/2-5,y-9,w+10,18);ctx.fillStyle="#fff";ctx.fillText(text,x,y);}
