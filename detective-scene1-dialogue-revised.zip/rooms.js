const door=(x,y,name,to,spawn)=>({x,y,name,to,spawn});
const rooms={
 booth:{name:'방송부실',color:'#edf4f9',objects:[{x:4,y:2,name:'편집장',id:'editor'}]},
 archive:{name:'자료실',color:'#f8f2e6',objects:[{x:4,y:3,name:'배우 기록',id:'record'},door(5,9,'방송부실','booth',[3,5])]},
 media:{name:'미디어실',color:'#edf6ee',objects:[{x:6,y:3,name:'검색 PC',id:'source'},door(5,9,'방송부실','booth',[6,5])]},
 editing:{name:'편집실',color:'#f4edf8',objects:[{x:5,y:3,name:'편집 책상',id:'desk'},door(5,9,'방송부실','booth',[5,6])]}
};
let room='booth';
const roomName=document.querySelector('#room-name');
roomName.textContent=rooms[room].name;
function enterRoom(to,[x,y]){
 room=to; player.x=x; player.y=y; pressed.clear(); roomName.textContent=rooms[to].name;
}

function blockedAt(x,y){
 if(room!=='booth') return false;
 const px=(x+.5)*TILE, py=(y+.97)*TILE;
 const furniture=boothFurniture.map(o=>o.box);
 const people=rooms.booth.objects.filter(o=>o.id==='editor').map(o=>[(o.x+.5)*TILE-10,(o.y+.97)*TILE-10,20,14]);
 return [...furniture,...people].some(([l,t,w,h])=>px+6>l&&px-6<l+w&&py+4>t&&py-4<t+h);
}
