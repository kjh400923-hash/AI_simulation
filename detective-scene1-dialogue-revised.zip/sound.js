let audio, soundOn=true;
function unlockSound(){if(!soundOn)return;try{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;audio??=new Audio();if(audio.state==='suspended') audio.resume().catch(()=>{});}catch{}}
window.addEventListener('keydown',unlockSound,{capture:true});window.addEventListener('pointerdown',unlockSound,{capture:true});
const toggle=document.querySelector('#sound-toggle');
toggle.onclick=()=>{soundOn=!soundOn;toggle.textContent=soundOn?'효과음 켜짐':'효과음 꺼짐';toggle.setAttribute('aria-pressed',String(soundOn));if(soundOn)unlockSound();};
function effect(kind){if(!soundOn||audio?.state!=='running')return;const tones={step:[105],talk:[420],sit:[210,310],get:[523,659,784,1047]}[kind];tones.forEach((hz,i)=>{const t=audio.currentTime+i*.085,o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.setValueAtTime(hz,t);g.gain.setValueAtTime(kind==='step'?.03:.07,t);g.gain.exponentialRampToValueAtTime(.001,t+.075);o.connect(g).connect(audio.destination);o.start(t);o.stop(t+.08);});}
let lastPosition, travel=0;
function updateSteps(dt,p){if(lastPosition)travel+=Math.hypot(p.x-lastPosition.x,p.y-lastPosition.y);lastPosition={x:p.x,y:p.y};if(travel>=.7){travel=0;effect('step');}}
