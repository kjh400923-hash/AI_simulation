const dialogue=document.querySelector('#dialogue');
const hint=document.querySelector('#hint');
function say(name,line,options=[]){
 document.querySelector('#speaker-face').hidden=name!=='편집장';
 pressed.clear(); document.querySelector('#npc-name').textContent=name; document.querySelector('#npc-line').textContent=line;
 const box=document.querySelector('#choices'); box.replaceChildren();
 for(const [label,fn] of options){const button=document.createElement('button'); button.type='button'; button.textContent=label; button.onclick=fn; box.append(button);}
 dialogue.querySelector("small").textContent="E / Esc 닫기";
 dialogue.hidden=false;
}
function updateHint(){const target=nearestNpc(player); const text=dialogue.hidden&&target?`E: ${target.name} ${target.to?'이동':target.id==='editor'?'대화':'조사'}`:''; if(hint.textContent!==text) hint.textContent=text;}
document.addEventListener('keydown',e=>{if(e.repeat|| (e.code!=='KeyE'&&e.key!=='Escape'))return; if(!dialogue.hidden){ dialogue.hidden=true; pressed.clear(); return; } if(e.code==='KeyE'){const target=nearestNpc(player);if(target?.to) enterRoom(target.to,target.spawn); else if(target) interact(target.id);}});
