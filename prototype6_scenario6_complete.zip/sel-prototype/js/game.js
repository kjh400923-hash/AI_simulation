window.Game = (() => {
  const TIMER_SECONDS = {normal:35, important:55, sudden:25};
  const clamp = n => Math.max(0, Math.min(100, n));
  const randomInt = ([min,max]) => Math.floor(Math.random()*(max-min+1))+min;
  const shuffle = items => [...items].sort(() => Math.random()-.5);
  let state = null;
  let timerId = null;

  function start(characterId, customName) {
    const character = GameData.characters.find(c=>c.id===characterId);
    if (!character) throw new Error('캐릭터를 찾을 수 없습니다.');
    state = {
      characterId, characterName:customName.trim()||character.name, turn:0,
      stats:Object.fromEntries(Object.entries(character.ranges).map(([key,range])=>[key,randomInt(range)])),
      flags:{}, fatigueTurns:0, history:[], dailyHistory:[],
      dailyExtraPool:shuffle(GameData.dailyExtras.map((_,index)=>index)), ended:false
    };
    return getState();
  }
  function getState(){return state?JSON.parse(JSON.stringify(state)):null;}
  function getEvent(){return state&&state.turn<GameData.events.length?GameData.events[state.turn]:null;}
  function getTimerSeconds(event=getEvent()){return TIMER_SECONDS[event?.kind||'normal']||35;}
  function requirementMet(condition){
    if(!condition)return true;
    if(condition.stat&&state.stats[condition.stat]<condition.min)return false;
    if(condition.stat&&condition.max!=null&&state.stats[condition.stat]>condition.max)return false;
    return true;
  }
  function getChoices(){
    const event=getEvent(); if(!event)return [];
    return shuffle(event.choices.map((item,index)=>{
      const statReady=requirementMet(item.condition);
      const strenuous=state.fatigueTurns>0&&((item.effects?.stress||0)>0||(item.effects?.academic||0)>1);
      return {...item,sourceIndex:index,unlocked:statReady&&!strenuous,lockReason:!statReady?`${GameData.statNames[item.condition.stat]} ${item.condition.min} 이상 필요`:strenuous?'과로 상태에서는 잠시 제한되는 선택':''};
    }));
  }
  function scaleEffects(effects,kind){
    const scale={
      academic:kind==='important'?{1:5,2:8,3:11}:{1:4,2:7,3:10},
      morality:kind==='important'?{1:4,2:7,3:10}:{1:3,2:6,3:9},
      friendship:kind==='important'?{1:4,2:6,3:9}:{1:3,2:5,3:8},
      stress:kind==='important'?{1:7,2:10,3:13}:{1:6,2:9,3:12}
    };
    return Object.fromEntries(Object.entries(effects).map(([key,value])=>{
      if(!value)return [key,0]; const table=scale[key]||scale.friendship; const n=Math.abs(value);
      return [key,Math.sign(value)*(table[n]??n*3)];
    }));
  }
  function resolveDailyEvents(eventIndex){
    if(!state||!GameData.events[eventIndex]?.background)return [];
    const scenes=[GameData.events[eventIndex].background];
    if(state.dailyExtraPool.length&&Math.random()<.35)scenes.push(GameData.dailyExtras[state.dailyExtraPool.pop()]);
    return scenes.map(scene=>{
      const result={title:scene.title,text:scene.text,impact:[]}; const reward=scene.reward;
      if(reward&&Math.random()<.25&&state.stats[reward.stat]<100){
        const before=state.stats[reward.stat];state.stats[reward.stat]=clamp(before+2);const amount=state.stats[reward.stat]-before;
        if(amount>0){result.text+=` ${reward.text}`;result.impact.push(`${GameData.statNames[reward.stat]} +${amount}`);state.dailyHistory.push({title:scene.title,stat:reward.stat,amount,text:reward.text});}
      }
      return result;
    });
  }
  function choose(choiceItem,timedOut=false){
    if(!state||state.ended)return null;
    if(timerId){clearInterval(timerId);timerId=null;}
    const event=getEvent();if(!event)return null;
    const strenuous=state.fatigueTurns>0&&((choiceItem.effects?.stress||0)>0||(choiceItem.effects?.academic||0)>1);
    if(!timedOut&&(!requirementMet(choiceItem.condition)||strenuous))return null;
    const effects=Object.fromEntries(Object.entries(choiceItem.effects||{}).map(([key,value])=>[key,choiceItem.exactEffectKeys?.includes(key)?value:scaleEffects({[key]:value},event.kind)[key]]));const before={...state.stats};
    let electionWon=null;
    if(event.title==='첫 반장 선거'&&choiceItem.flag==='ranForClassPresident'){
      const winChance=Math.max(25,Math.min(75,30+state.stats.friendship*.4));electionWon=Math.random()*100<winChance;
    }
    Object.entries(effects).forEach(([key,value])=>{if(key in state.stats)state.stats[key]=clamp(state.stats[key]+value);});
    let impact=[];
    let result=choiceItem.result||`“${choiceItem.text}”라는 선택을 실제로 옮겼다. ${choiceItem.detail||''}`;
    if(electionWon===true){state.flags.electedClassPresident=true;result='친구들의 투표 결과, 당신이 반장으로 당선되었다. 학급의 의견을 듣고 선생님과 친구들 사이에서 소통을 돕는 역할을 맡게 되었다. 이제 친구들의 목소리를 잘 전달하고 맡은 일을 책임 있게 해나갈 차례다.';}
    else if(electionWon===false){state.flags.electedClassPresident=false;result='친구들의 투표 결과, 다른 후보가 반장으로 당선되었다. 이번에는 당선되지 않았지만, 입후보해 자신의 생각을 말한 경험은 남았다. 앞으로도 학급에서 기여할 방법을 찾아볼 수 있다.';}
    if(timedOut)result=`시간이 끝나 기본 선택이 자동으로 진행되었다. ${result}`;
    if(choiceItem.flag)state.flags[choiceItem.flag]=true;
    if(event.title==='지호에게 손을 내밀다'&&['helpedJiho','supportedJiho'].includes(choiceItem.flag))state.flags.jihoSupported=true;
    if(event.title==='불편한 장난'&&choiceItem.flag==='supportedJiho')state.flags.jihoSupported=true;
    if(state.stats.stress>=100){
      state.stats.stress=82;state.stats.academic=clamp(state.stats.academic-2);state.stats.friendship=clamp(state.stats.friendship-1);state.fatigueTurns=2;
      result+=' 스트레스가 한계에 도달해 과로 상태가 되었다. 잠시 회복이 필요해 학업능력 -2, 교우관계 -1이 적용되고 다음 두 턴에는 무리한 선택이 제한된다.';
      impact.push('과로 페널티: 스트레스 82, 학업능력 -2, 교우관계 -1');
    }else if(state.fatigueTurns>0)state.fatigueTurns--;
    impact=Object.keys(before).filter(key=>state.stats[key]!==before[key]).map(key=>`${GameData.statNames[key]} ${state.stats[key]-before[key]>0?'+':''}${state.stats[key]-before[key]}`);
    state.history.push({month:event.month,title:event.title,choice:choiceItem.text,result,effects:impact,stats:{...state.stats},timedOut,flags:{...state.flags}});
    state.turn++;if(state.turn>=GameData.events.length)state.ended=true;
    return {result,impact,before,after:{...state.stats},timedOut,ended:state.ended};
  }
  function startTimer(onTick,onTimeout){if(timerId)clearInterval(timerId);let remaining=getTimerSeconds();onTick(remaining);timerId=setInterval(()=>{remaining--;onTick(remaining);if(remaining<=0){clearInterval(timerId);timerId=null;onTimeout();}},1000);}
  function stopTimer(){if(timerId){clearInterval(timerId);timerId=null;}}
  function getEnding(){
    if(!state)return null;const s=state.stats;const history=state.history;
    const jihoHelped=!!(state.flags.jihoSupported||history.some(h=>['helpedJiho','supportedJiho','toldAdultJiho'].some(k=>h.flags?.[k])));
    let title,text;
    if(s.stress>=78){title='잠시 멈춰, 다시 균형을 찾는 졸업';text='세 해 동안 부담이 크게 쌓였어요. 졸업은 끝이 아니라 회복을 배울 다음 단계의 시작입니다. 믿을 만한 사람에게 도움을 요청하고, 휴식과 계획을 함께 세워도 괜찮아요.';}
    else if(s.academic>=78&&s.morality>=60){title='배움과 배려를 함께 키운 졸업';text='꾸준히 배우는 힘과 주변을 살피는 태도를 함께 길렀어요. 성취를 혼자만의 결과로 두지 않고, 배운 것을 다른 사람과 나누는 사람으로 성장했습니다.';}
    else if(s.academic>=78){title='호기심을 성취로 바꾼 졸업';text='궁금한 것을 파고들고 계획을 실천하는 힘이 크게 자랐어요. 앞으로도 결과만 좇기보다 자신에게 맞는 배움의 방법을 찾아갈 수 있습니다.';}
    else if(s.morality>=75&&s.friendship>=60){title='믿음과 관계를 키운 졸업';text='상대의 입장을 살피고 책임 있는 행동을 이어왔어요. 사람들과 신뢰를 쌓고, 필요할 때 안전한 도움을 연결하는 힘이 자랐습니다.';}
    else if(s.friendship>=75){title='함께하는 힘을 발견한 졸업';text='새로운 사람에게 다가가고 관계를 이어가는 경험이 쌓였어요. 서로의 차이를 존중하며 함께할 방법을 찾는 힘이 자랐습니다.';}
    else if(s.stress<=30&&s.academic>=60){title='나만의 속도로 성장한 졸업';text='학습 목표와 회복의 균형을 스스로 조절하는 힘을 길렀어요. 자신에게 맞는 속도를 찾는 일이 오래 이어지는 성장을 만든다는 것을 경험했습니다.';}
    else if(s.morality>=70){title='책임 있는 선택을 배운 졸업';text='행동이 다른 사람에게 미치는 영향을 살피고, 어려운 순간에 책임 있게 반응하는 연습을 해왔어요. 작은 선택들이 당신의 기준을 만들었습니다.';}
    else{text='완벽한 선택만 한 것은 아니지만, 여러 상황을 지나며 자신에게 중요한 기준과 앞으로 연습하고 싶은 점을 발견했어요. 경험을 돌아보고 다시 선택하는 힘도 성장의 일부입니다.';title='각자의 길을 시작하는 졸업';}
    const achievements=[];
    if(s.academic>=70)achievements.push({icon:'📚',name:'꾸준한 탐구자',description:'학업능력 70 이상으로 성장'});
    if(s.morality>=70)achievements.push({icon:'🧭',name:'책임 있는 선택',description:'도덕성 70 이상 달성'});
    if(s.friendship>=70)achievements.push({icon:'🤝',name:'관계의 다리',description:'교우관계 70 이상 달성'});
    if(s.stress<=35)achievements.push({icon:'🌿',name:'나를 돌보는 힘',description:'졸업 시 스트레스 35 이하 유지'});
    if(state.flags.electedClassPresident)achievements.push({icon:'🏅',name:'학급의 목소리',description:'반장으로 당선'});
    if(state.flags.groupCooperation||history.some(h=>h.flags?.groupCooperation))achievements.push({icon:'🧩',name:'함께 만든 결과',description:'조별 과제에서 역할과 일정을 조율'});
    if(state.flags.jihoSupported||jihoHelped)achievements.push({icon:'💛',name:'곁을 지킨 친구',description:'지호에게 안전한 도움을 연결하거나 곁을 지킴'});
    if(state.flags.festivalCooperation||history.some(h=>h.flags?.festivalCooperation))achievements.push({icon:'🎪',name:'함께 준비한 축제',description:'축제 준비에서 역할과 의견을 나눔'});
    if(achievements.length===0)achievements.push({icon:'🌱',name:'첫걸음',description:'3년의 여정을 마치고 자신의 경험을 돌아봄'});
    const schoolNote=jihoHelped?'지호는 믿을 수 있는 어른과 연결되고 자기 속도대로 학교생활을 이어갔습니다. 한 번의 행동이 모든 문제를 해결한 것은 아니지만, 도움을 요청하고 곁에 있어 준 것이 지원의 시작이 되었습니다.':'지호의 어려움은 충분히 일찍 알려지지 않았습니다. 괴롭힘의 책임은 괴롭힌 사람에게 있습니다. 비슷한 상황에서는 혼자 해결하려 하기보다 믿을 수 있는 어른에게 알리고 당사자의 안전과 의사를 존중하며 도움을 연결할 수 있습니다.';
    return {title,text,schoolNote,jihoHelped,history,dailyHistory:state.dailyHistory,stats:{...s},name:state.characterName,achievements};
  }
  return {start,getState,getEvent,getChoices,getTimerSeconds,choose,resolveDailyEvents,startTimer,stopTimer,getEnding,scaleEffects};
})();
