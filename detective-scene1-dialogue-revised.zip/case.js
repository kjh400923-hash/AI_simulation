const goal = document.querySelector('#goal');
const clues = new Set();
const notes = {
 record:'배우 기록: 캐리 피셔는 2016년에 사망했다.',
 source:'스타워즈 공식 발표(2018.7.27, 에피소드 IX): 제작진은 이전 작품인 《깨어난 포스》를 위해 촬영해 둔 미공개 영상을 활용한다고 밝혔다. (요약)',
 consent:'유족 메시지: 생전에 녹음한 목소리를 추모 영상에 쓰는 데 동의합니다.',
 memo:'제작 메모: AI로 “올해 영화제에 꼭 오세요”라는 새 홍보 멘트를 만들었다.',
 preview:'예고편 점검: 새 홍보 멘트에 AI 합성 안내가 없다.'
};
let phase=0;
const goals=['방송부실의 편집장에게 가서 E를 누르세요.','장면 1 미리보기: 다른 장소는 아직 열리지 않았어요.','편집실의 책상에서 가상 영화제 자료 3개를 읽고 방송부실로 돌아가세요.','사건 해결! 수첩을 펼쳐 판단 근거를 다시 볼 수 있어요.'];
function setPhase(n){ phase=n; goal.textContent=goals[n]; }
setPhase(0);
function collect(id){ if(clues.has(id)) return; clues.add(id); const li=document.createElement('li'); li.textContent=notes[id]; document.querySelector('#notebook ul').append(li); }
function interact(id){
 if(id==='editor'){
  if(phase===0){setPhase(1); return say('편집장','제보 기사: 《스타워즈: 라이즈 오브 스카이워커》 제작진이 캐리 피셔를 AI로 복원해 레아 공주로 출연시켰다. 이대로 방송해도 될지 자료실의 배우 기록과 미디어실의 검색 PC를 조사해 줘.');}
  if(phase===1){if(!clues.has('record')||!clues.has('source')) return say('편집장','수사노트를 살펴보게. 나머지 조사는 다음 장면에서 이어가세.'); return verdict();}
  if(phase===2){if(!['consent','memo','preview'].every(k=>clues.has(k))) return say('편집장','편집 책상에서 세 자료를 각각 열어 봐.'); return ethics();}
  return say('편집장','첫 기사는 정정했고, 가상 영화제 예고편은 수정 전까지 방송하지 않기로 했어.');
 }
 if(id==='desk') return phase>=2 ? desk() : say('편집 책상','아직 검토할 자료가 없다.');
 if(!phase) return say('조사 안내','먼저 편집장에게 기사를 받자.');
 collect(id);
 say(id==='record'?'자료실':'검색 PC',notes[id]+(id==='record'?' 학생 기자: “그럼 개봉 전에 돌아가셨으니 영화에 아예 안 나온 거 아닐까?” (학생의 의견)':''));
}
function verdict(){ say('편집장','어떤 문장을 방송할까?',[
 ['AI로 복원해 출연했다.',()=>factFeedback('AI 복원을 확인해 주는 자료가 있었을까?')],
 ['개봉 전 사망했으므로 출연하지 않았다.',()=>factFeedback('개봉 전에 돌아가셨다는 기록만으로 영화에 나오지 않았다고 할 수 있을까?')],
 ['영화에 등장했다. 제작진은 과거 미공개 촬영 영상을 활용했다고 밝혔다.',basis]
 ]); }
function factFeedback(text){say('편집장',text,[['다시 판단하기',verdict]]);}
function basis(){say('편집장','출연 방식을 확인할 수 있는 근거는?',[
 ['배우 사망 기록',()=>say('편집장','사망 기록은 출연에 어떤 영상이 쓰였는지 알려주지 않아.',[['근거 다시 고르기',basis]])],
 ['제작진 공식 발표',()=>{setPhase(2);say('편집장','좋아. 출연은 사실이지만 방법이 잘못됐으니 기사를 정정하자. 이번에는 정말 AI를 쓴 가상 영화제 예고편이 들어왔어. 돌아가신 성우의 목소리로 새 홍보 멘트를 만들었대. 편집 책상에서 자료를 확인해 줘.');}]
 ]);}
function desk(){say('편집 책상','어떤 자료를 읽을까?',[['유족 메시지','consent'],['제작 메모','memo'],['예고편 점검','preview']].map(([label,id])=>[label+(clues.has(id)?' ✓':''),()=>{collect(id);say(label,notes[id],[['다른 자료 읽기',desk]]);} ]));}
function ethics(){say('편집장','가상 영화제 예고편을 어떻게 할까?',[
 ['AI 합성이라고 표시하고 지금 버전을 방송한다.',()=>say('편집장','시청자는 합성인 걸 알겠네. 그런데 추모용 기존 녹음에 대한 동의가 새 홍보 멘트에도 적용될까?', [['다시 판단하기',ethics]])],
 ['방송을 보류하고 AI 홍보 멘트에 대한 동의를 다시 확인한다.',()=>why('hold')],
 ['합성 멘트를 빼고 진행자가 직접 읽도록 바꾼다.',()=>why('replace')]
 ]);}
function why(route){say('편집장','지금 버전을 그대로 내보내지 않는 가장 직접적인 이유는?',[
 ['유족은 기존 녹음의 추모 사용에 동의했지, 새 홍보 멘트 합성에 동의한 건 확인되지 않았다.',()=>{setPhase(3);say('편집장',(route==='hold'?'동의 범위를 다시 확인하고, 합성본을 쓰게 된다면 시청자에게도 그 사실을 알리자.':'합성 음성을 빼고 진행자가 직접 읽은 수정본을 확인하자.')+' 기사 검증과 방송 결정이 모두 끝났어!');}],
 ['합성 안내만 붙이면 사용 허락도 해결된다.',()=>say('편집장','시청자에게 알리는 것과 목소리 사용에 동의를 받는 건 다른 문제야.',[['근거 다시 고르기',()=>why(route)],['방송 결정 다시 보기',ethics]])]
 ]);}
