(() => {
  const $=selector=>document.querySelector(selector);
  const setup=$('#setup'),story=$('#story'),dialog=$('#choiceDialog'),dialogContent=$('#choiceDialogContent');
  const startButton=$('#startGame'),activeTurn=$('#activeTurn'),log=$('#storyLog');
  let timerText=null,selecting=false;
  function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function appendEntry({meta,title,text,choiceText,impact,type=''}){
    const article=document.createElement('article');article.className=`log-entry ${type}`.trim();
    article.innerHTML=`${meta?`<div class="log-meta">${escapeHtml(meta)}</div>`:''}${title?`<h2>${escapeHtml(title)}</h2>`:''}${text?`<p>${escapeHtml(text)}</p>`:''}${choiceText?`<p class="choice-line">선택: ${escapeHtml(choiceText)}</p>`:''}${impact?.length?`<p class="impact">${impact.map(escapeHtml).join(' · ')}</p>`:''}`;
    log.append(article);scrollDown();
  }
  function scrollDown(){requestAnimationFrame(()=>window.scrollTo({top:document.documentElement.scrollHeight,behavior:'smooth'}));}
  function statMarkup(stats){return Object.entries(GameData.statNames).map(([key,label])=>`<div class="profile-stat ${key==='stress'?'stress':''}"><div><span>${label}</span><strong>${stats[key]}</strong></div><div class="meter"><i style="width:${stats[key]}%"></i></div></div>`).join('');}
  function updateStats(){
    const state=Game.getState();if(!state)return;
    $('#playerLabel').textContent=`${state.characterName} · ${Math.min(state.turn+1,36)}/${GameData.events.length}개월`;
    $('#gradeLabel').textContent=state.turn<12?'1학년':state.turn<24?'2학년':state.turn<36?'3학년':'졸업';
    $('#statList').innerHTML=statMarkup(state.stats);
  }
  function setNext(label,action){
    activeTurn.innerHTML='';const button=document.createElement('button');button.type='button';button.className='primary-button next-button';button.textContent=label;button.addEventListener('click',action,{once:true});activeTurn.append(button);scrollDown();
  }
  function renderCharacterProfile(character,state){
    $('#storyTitle').textContent='나의 캐릭터';$('#storySubtitle').textContent='무작위로 배정된 캐릭터를 확인하고 다음을 눌러 시작하세요.';
    activeTurn.innerHTML=`<section class="profile-card"><p class="eyebrow">플레이어 프로필</p><h2>${escapeHtml(state.characterName)}</h2><span class="profile-tag">${escapeHtml(character.tag)}</span><p class="profile-description">${escapeHtml(character.profile)}</p><h3>현재 스탯</h3><div class="profile-stats">${statMarkup(state.stats)}</div></section>`;
    const next=document.createElement('button');next.type='button';next.className='primary-button next-button';next.textContent='다음 · 이야기 시작';next.addEventListener('click',startStory,{once:true});activeTurn.append(next);
  }
  function startStory(){
    activeTurn.innerHTML='';$('#storyTitle').textContent='입학식 날, 교실 앞';$('#storySubtitle').textContent='첫 선택에 앞서 학교의 분위기를 살펴봅니다.';
    appendEntry({meta:'프롤로그 · 일상 장면',title:'교실 문 앞에서',text:'새 교복의 소매가 아직 어색하다. 복도에는 새 학년의 목소리가 겹쳐 들리고, 교실 안에서는 책상을 옮기는 소리가 난다. 문 앞에서 잠깐 숨을 고르자 긴장과 기대가 함께 느껴진다. 오늘은 이름을 외우고 교실의 분위기를 익히는 것부터 시작해도 괜찮다.',type:'background-log'});
    updateStats();setNext('첫 선택 이벤트 열기',renderTurn);
  }
  function renderTurn(){
    const event=Game.getEvent();if(!event){renderEnding();return;}
    selecting=false;const state=Game.getState(),turnNumber=state.turn+1;
    $('#storyTitle').textContent=`${turnNumber}번째 달 · ${event.title}`;$('#storySubtitle').textContent=`${event.month} · 선택 이벤트`;
    appendEntry({meta:`${turnNumber}개월째 · ${event.month} · 선택 이벤트`,title:event.title,text:event.scene,type:'selection-log'});
    if(event.shared)appendEntry({meta:'공동 이벤트 안내',text:'현재 체험판은 개인 플레이입니다. 조원 선택의 비공개 집계는 서버 연동 후 적용할 수 있습니다.'});
    if(state.fatigueTurns>0)appendEntry({meta:'컨디션 알림',text:`과로 상태가 남아 있습니다. 회복과 부담 조절을 우선해 보세요. (${state.fatigueTurns}턴 남음)`});
    updateStats();openChoiceDialog(event,turnNumber);
  }
  function openChoiceDialog(event,turnNumber){
    dialogContent.innerHTML='';
    const eyebrow=document.createElement('p');eyebrow.className='eyebrow';eyebrow.textContent=`${event.month} · ${event.kind==='important'?'중요한 선택':event.kind==='sudden'?'돌발 선택':'선택 이벤트'}`;
    const heading=document.createElement('h2');heading.id='choiceDialogTitle';heading.textContent=`${turnNumber}번째 선택 · ${event.title}`;
    const scene=document.createElement('p');scene.className='dialog-scene';scene.textContent=event.scene;
    const prompt=document.createElement('p');prompt.className='prompt';prompt.textContent=event.prompt;
    const timerLine=document.createElement('div');timerLine.className='dialog-timer-row';const label=document.createElement('span');label.textContent='선택 제한 시간';
    timerText=document.createElement('span');timerText.className='timer';timerText.textContent=`${Game.getTimerSeconds(event)}초`;timerLine.append(label,timerText);
    const choicesWrap=document.createElement('div');choicesWrap.className='choices';
    Game.getChoices().forEach((item,index)=>{
      const button=document.createElement('button');button.type='button';button.className=`choice-button ${item.unlocked?'':'locked'}`;button.disabled=!item.unlocked;
      button.innerHTML=`<span class="choice-number">${index+1}</span><span class="choice-copy"><strong>${escapeHtml(item.text)}${item.unlocked?'':` <span class="locked-label">🔒 ${escapeHtml(item.lockReason||'조건 미충족')}</span>`}</strong><small>${escapeHtml(item.detail||'')}</small></span>`;
      button.addEventListener('click',()=>makeChoice(item,false));choicesWrap.append(button);
    });
    dialogContent.append(eyebrow,heading,scene,prompt,timerLine,choicesWrap);if(!dialog.open)dialog.showModal();
    const first=choicesWrap.querySelector('button:not(:disabled)');if(first)first.focus({preventScroll:true});
    Game.startTimer(seconds=>{timerText.textContent=`${seconds}초`;timerText.classList.toggle('urgent',seconds<=10);},()=>makeChoice(Game.getChoices().find(c=>c.unlocked)||Game.getChoices()[0],true));
  }
  function makeChoice(item,timedOut){
    if(selecting||!item)return;selecting=true;Game.stopTimer();const eventIndex=Game.getState().turn,event=GameData.events[eventIndex];
    const result=Game.choose(item,timedOut);if(!result){selecting=false;return;}if(dialog.open)dialog.close();
    const record=Game.getState().history.at(-1);appendEntry({meta:`${record.month} · 선택 결과`,choiceText:record.choice,text:record.result,impact:record.effects,type:'result-log'});updateStats();
    if(result.ended){renderEnding();return;}
    setNext('일상 장면 보기',()=>showDailyInterlude(eventIndex));
  }
  function showDailyInterlude(eventIndex){
    activeTurn.innerHTML='';const scenes=Game.resolveDailyEvents(eventIndex);
    scenes.forEach((scene,index)=>appendEntry({meta:`일상 장면 ${index+1}/${scenes.length} · 선택 없이 읽기`,title:scene.title,text:scene.text,impact:scene.impact,type:'background-log'}));
    updateStats();setNext('다음 선택 이벤트',renderTurn);
  }
  function renderEnding(){
    Game.stopTimer();const ending=Game.getEnding();$('#storyTitle').textContent='졸업식 · 3년의 이야기';$('#storySubtitle').textContent=`${ending.name}의 엔딩`;
    appendEntry({meta:'36개월의 끝',title:'졸업식 날',text:'교복을 입는 마지막 날. 세 해 동안의 선택과 작은 일상이 쌓여 지금의 나를 만들었다.',type:'ending-log'});
    const stats=Object.entries(GameData.statNames).map(([key,label])=>`<div class="ending-stat ${key==='stress'?'stress':''}"><span>${label}</span><strong>${ending.stats[key]}</strong></div>`).join('');
    const badges=ending.achievements.map(a=>`<div class="achievement"><span class="achievement-icon">${a.icon}</span><div><strong>${escapeHtml(a.name)}</strong><small>${escapeHtml(a.description)}</small></div></div>`).join('');
    activeTurn.innerHTML=`<section class="ending-card"><p class="eyebrow">나의 결말</p><h2>${escapeHtml(ending.title)}</h2><p>${escapeHtml(ending.text)}</p><div class="ending-stats">${stats}</div><h3>나의 업적</h3><div class="achievement-list">${badges}</div><h3>지호의 이야기</h3><p>${escapeHtml(ending.schoolNote)}</p><p class="reflection"><strong>돌아보기</strong><br>가장 고민됐던 선택은 무엇이었나요? 그때 나와 타인의 필요를 어떻게 함께 생각했나요?</p><p class="reflection">이 결과는 개인 플레이 기준입니다. 조별 공동 결과는 서버 연동 후 집계할 수 있습니다.</p></section>`;
    $('#resetGame').hidden=false;updateStats();scrollDown();
  }
  function begin(){
    const character=GameData.characters[Math.floor(Math.random()*GameData.characters.length)];
    const state=Game.start(character.id,$('#playerName').value||'');setup.hidden=true;story.hidden=false;$('#resetGame').hidden=false;
    $('#playerLabel').textContent=state.characterName;$('#gradeLabel').textContent='캐릭터 확인';updateStats();renderCharacterProfile(character,state);
  }
  function reset(){Game.stopTimer();selecting=false;if(dialog.open)dialog.close();log.innerHTML='';activeTurn.innerHTML='';story.hidden=true;setup.hidden=false;$('#resetGame').hidden=true;startButton.disabled=false;startButton.textContent='무작위 캐릭터 만들기';$('#playerName').value='';window.scrollTo({top:0,behavior:'smooth'});}
  dialog.addEventListener('cancel',event=>event.preventDefault());startButton.addEventListener('click',begin);$('#resetGame').addEventListener('click',reset);$('#toggleStats').addEventListener('click',()=>$('#statsPanel').classList.toggle('hidden'));
})();
